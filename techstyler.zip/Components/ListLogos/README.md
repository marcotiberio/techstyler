# List Logos

Upload logos (gif, jpg, png or svg) that will line up centered. Allows links for each logo and has an optional card layout.
