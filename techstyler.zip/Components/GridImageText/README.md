# Grid Image Text

Up to 4 items with an image and WYSIWYG each. Can be used for any kind of static content. Has an optional card style.
