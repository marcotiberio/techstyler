# Flynt Premium Components

Congratulations for buying Flynt’s Premium Components!

There are 2 options to get started:
1. Drag and drop individual components that you need in your project into your Flynt Theme Components folder.
2. Move the whole folder in your Flynt Theme Components folder (and make sure the folder name is `PremiumComponents`). The Premium Components will now show up in your pageComponents Field Group.

If you want to keep the PremiumComponents folder structure, you can add components to existing Field Groups by adjusting the `functions.php`.
