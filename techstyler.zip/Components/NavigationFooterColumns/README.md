# Navigation Footer Columns

A WordPress navigation split into columns with a logo and social links. Works well in combination with Navigation Footer.
