# Block Image

Image with optional caption, multiple size options and optimized responsive image sizes.
