# Block Image Medium

Image with optional caption, multiple size options and optimized responsive image sizes.
