# Form Newsletter

Displays a predefined newsletter form that can be configured via Translatable Options. Is dependent on the FormContactForm7 component.
