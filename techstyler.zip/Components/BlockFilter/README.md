# Block Filter

The collapse block reduces the vertical space between components. Simply move the component in between components with same color themes.
