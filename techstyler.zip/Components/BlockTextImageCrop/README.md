# Block Text Image Crop

Image and text have equal weight, though the image isn’t resized proportionally but is sized according to the text height and gets cropped when resized.
