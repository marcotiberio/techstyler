# Slider Text

Simply drop any images on the gallery field, order them by drag & drop and optionally add a caption per image. No need to worry about the photo selection as any image ratio will fit into the slider.
