# Feature Admin Component Screenshots

Shows a component preview in the WordPress back end in the "Add Component" menu and next to the title of a component that was added to the page. The feature loads the `screenshot.png` from each component folder.
