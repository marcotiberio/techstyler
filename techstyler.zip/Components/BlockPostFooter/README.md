# Block Post Footer

Displays post tags and author information when added to a single post template.
