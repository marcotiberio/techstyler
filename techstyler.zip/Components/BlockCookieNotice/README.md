# Block Cookie Notice

On a first visit, the website visitor will see this notice at the bottom of the screen, until dismissed with a click on the button. Custom formatted text and a button label can be set in Translatable Options.
