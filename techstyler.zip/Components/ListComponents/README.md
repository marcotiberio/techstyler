# List Components

Allowing the preview and discovery of components within a theme. The title, description and component screenshots are automatically loaded from the component folder by finding the `screenshot.png` and parsing the `README.md` file. Call to Action buttons can be added optionally.
